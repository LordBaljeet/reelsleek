// Listen for tab updates
let currentURL = "";

function setDefaultVolume(default_volume) {
  browser.storage.local.set({ default_volume: default_volume });
}

function handleInstalled(details) {
  browser.storage.local.get("default_volume").then({}, setDefaultVolume(10));
}

browser.runtime.onInstalled.addListener(handleInstalled);

browser.tabs.onUpdated.addListener(
  async (tabId, changeInfo, tab) => {
    if (tab.url.includes("instagram.com")) {
      if (tab.url === currentURL) {
        return;
      }
      console.debug(
        `Tab URL changed: ${tabId}, ${JSON.stringify(
          changeInfo,
        )}, ${JSON.stringify(tab)}`,
      );
      currentURL = tab.url;
      try {
        await browser.scripting.executeScript({
          target: {
            tabId: tabId,
          },
          files: ["content.js"],
        });
      } catch (err) {
        console.log("error injecting script: ", err);
      }
    }
  },
  {
    properties: ["url"],
  },
);
