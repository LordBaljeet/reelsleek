const ORIENTATION_KEY = "ig_volume_orientation";
const VOLUME_ALWAYS_VISIBLE_KEY = "ig_volume_always_visible";
const SEEKBAR_ALWAYS_VISIBLE_KEY = "ig_seekbar_always_visible";

const statusPill = document.getElementById("statusPill");
const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const orientToggle = document.getElementById("orientToggle");
const reloadBtn = document.getElementById("reloadBtn");
const toast = document.getElementById("toast");
const logo = document.getElementById("logo");
const volumeState = document.getElementById("volume-state");
const muteState = document.getElementById("mute-state");
const container = document.getElementById("container");
const permBanner = document.getElementById("permBanner");
const permBtn = document.getElementById("permBtn");

let activeState;

// ── Permission banner ─────────────────────────────────────────────────────────

async function checkPermission() {
  const granted = await browser.runtime.sendMessage({ type: "checkPermission" });
  permBanner.hidden = granted;
  return granted;
}

permBtn.addEventListener("click", async () => {
  permBtn.disabled = true;
  permBtn.textContent = "Waiting…";
  // Must be called directly from the click handler — not via a background message
  const granted = await browser.permissions.request({
    origins: ["*://*.instagram.com/*"],
  });
  if (granted) {
    permBanner.hidden = true;
    await checkStatus();
  } else {
    permBtn.disabled = false;
    permBtn.textContent = "Grant access";
    showToast("Permission denied", "err");
  }
});

// ── Status pill ───────────────────────────────────────────────────────────────

function setStatus(state) {
  statusPill.className = "status-pill " + state;
  statusDot.className = "dot" + (state === "active" ? " pulse" : "");
  activeState =
    state === "active" ? "active" : state === "error" ? "error" : "inactive";
  statusText.textContent = activeState;
  if (state === "active") {
    container.classList.toggle("active", state === "active");
  }
}

async function checkStatus() {
  const permitted = await checkPermission();
  if (!permitted) {
    setStatus("inactive");
    return;
  }

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    setStatus("inactive");
    return;
  }

  const isIG = /^https:\/\/(www\.)?instagram\.com/.test(tab.url);
  if (!isIG) {
    setStatus("inactive");
    return;
  }

  const response = await browser.tabs
    .sendMessage(tab.id, { type: "ping" })
    .catch(() => null);
  setStatus(response ? "active" : "error");
  if (response) {
    volumeState.textContent = `${response.volume * 100}%`;
    muteState.textContent = `${response.muted}`;
  }
}

// ── Toast ─────────────────────────────────────────────────────────────────────

let toastTimer = null;
function showToast(msg, type = "") {
  toast.textContent = msg;
  toast.className = "toast " + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.textContent = "";
    toast.className = "toast";
  }, 1500);
}

// ── Orientation toggle ────────────────────────────────────────────────────────

async function loadOrientation() {
  const result = await browser.storage.local.get(ORIENTATION_KEY);
  return result[ORIENTATION_KEY] ?? "horizontal";
}

async function saveOrientation(value) {
  await browser.storage.local.set({ [ORIENTATION_KEY]: value });
}

function applyOrientation(value) {
  orientToggle.className = "orient-toggle " + value;
}

async function broadcastOrientation(value) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  browser.tabs
    .sendMessage(tab.id, { type: "setOrientation", value })
    .catch(() => null);
}

orientToggle.querySelectorAll(".orient-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const value = btn.dataset.orient;
    applyOrientation(value);
    await saveOrientation(value);
    await broadcastOrientation(value);
    showToast("saved", "ok");
  });
});

const volumeVisToggle = document.getElementById("volumeVisToggle");
const seekbarVisToggle = document.getElementById("seekbarVisToggle");

// ── Visibility toggles ────────────────────────────────────────────────────────

function applyVisToggle(toggleEl, alwaysVisible) {
  toggleEl.querySelectorAll(".vis-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.vis === (alwaysVisible ? "always" : "hover"));
  });
}

async function broadcastVisibility(type, value) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  browser.tabs.sendMessage(tab.id, { type, value }).catch(() => null);
}

function setupVisToggle(toggleEl, storageKey, messageType) {
  toggleEl.querySelectorAll(".vis-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const alwaysVisible = btn.dataset.vis === "always";
      applyVisToggle(toggleEl, alwaysVisible);
      await browser.storage.local.set({ [storageKey]: alwaysVisible });
      await broadcastVisibility(messageType, alwaysVisible);
      showToast("saved", "ok");
    });
  });
}

setupVisToggle(volumeVisToggle, VOLUME_ALWAYS_VISIBLE_KEY, "setVolumeAlwaysVisible");
setupVisToggle(seekbarVisToggle, SEEKBAR_ALWAYS_VISIBLE_KEY, "setSeekbarAlwaysVisible");

// ── Reload button ─────────────────────────────────────────────────────────────

reloadBtn.addEventListener("click", async () => {
  reloadBtn.classList.add("spinning");
  reloadBtn.disabled = true;

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    await browser.tabs.reload(tab.id);
  }

  window.close();
});

// ── Boot ──────────────────────────────────────────────────────────────────────

(async () => {
  const orientation = await loadOrientation();
  applyOrientation(orientation);

  const result = await browser.storage.local.get([
    VOLUME_ALWAYS_VISIBLE_KEY,
    SEEKBAR_ALWAYS_VISIBLE_KEY,
  ]);
  applyVisToggle(volumeVisToggle, result[VOLUME_ALWAYS_VISIBLE_KEY] ?? false);
  applyVisToggle(seekbarVisToggle, result[SEEKBAR_ALWAYS_VISIBLE_KEY] ?? false);

  await checkStatus();
})();