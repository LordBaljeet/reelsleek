const ORIENTATION_KEY = "ig_volume_orientation";

const statusPill = document.getElementById("statusPill");
const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const orientToggle = document.getElementById("orientToggle");
const reloadBtn = document.getElementById("reloadBtn");
const toast = document.getElementById("toast");
const logo = document.getElementById("logo");
const volumeState = document.getElementById("volume-state");
const muteState = document.getElementById("mute-state");
const container = document.getElementById("container");

let activeState;
// ── Status pill ───────────────────────────────────────────────────────────────

function setStatus(state) {
  statusPill.className = "status-pill " + state;
  statusDot.className = "dot" + (state === "active" ? " pulse" : "");
  activeState =
    state === "active" ? "active" : state === "error" ? "error" : "inactive";
  statusText.textContent = activeState;
  if(state === "active") {
    container.classList.toggle('active', state === "active");
  }
}

async function checkStatus() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    setStatus("inactive");
    return;
  }

  const isIG = /^https:\/\/(www\.)?instagram\.com/.test(tab.url);
  if (!isIG) {
    setStatus("inactive");
    return;
  }

  const response = await browser.tabs.sendMessage(tab.id, { type: "ping" }).catch(() => null);
  setStatus(response ? "active" : "error");
  if (response) {
    volumeState.textContent = `${response.volume * 100}%`
    muteState.textContent = `${response.muted}`
  }
}

// ── Toast ─────────────────────────────────────────────────────────────────────

let toastTimer = null;
function showToast(msg, type = "") {
  toast.textContent = msg;
  toast.className = "toast " + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.textContent = "";
    toast.className = "toast";
  }, 1500);
}

// ── Orientation toggle ────────────────────────────────────────────────────────

async function loadOrientation() {
  const result = await browser.storage.local.get(ORIENTATION_KEY);
  return result[ORIENTATION_KEY] ?? "horizontal";
}

async function saveOrientation(value) {
  await browser.storage.local.set({ [ORIENTATION_KEY]: value });
}

function applyOrientation(value) {
  orientToggle.className = "orient-toggle " + value;
}

// Notify the content script so it can swap the class live without a reload
async function broadcastOrientation(value) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  browser.tabs
    .sendMessage(tab.id, { type: "setOrientation", value })
    .catch(() => null);
}

orientToggle.querySelectorAll(".orient-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const value = btn.dataset.orient;
    applyOrientation(value);
    await saveOrientation(value);
    await broadcastOrientation(value);
    showToast("saved", "ok");
  });
});

// ── Reload button ─────────────────────────────────────────────────────────────

reloadBtn.addEventListener("click", async () => {
  reloadBtn.classList.add("spinning");
  reloadBtn.disabled = true;

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    await browser.tabs.reload(tab.id);
  }

  // Close the popup — the page reload handles re-injecting the content script
  window.close();
});

// ── Boot ──────────────────────────────────────────────────────────────────────

(async () => {
  const orientation = await loadOrientation();
  applyOrientation(orientation);
  await checkStatus();
})();
