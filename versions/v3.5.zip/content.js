const STORAGE_KEY = "ig_volume_knob";
const ORIENTATION_KEY = "ig_volume_orientation";
const VOLUME_ALWAYS_VISIBLE_KEY = "ig_volume_always_visible";
const SEEKBAR_ALWAYS_VISIBLE_KEY = "ig_seekbar_always_visible";
const AUTOSCROLL_ENABLED_KEY = "ig_autoscroll"
const SKIP_SECONDS = 5;
const VOLUME_STEP = 0.1;

let videoVolume = 0.1;
let videoMuted = false;
let autoScroll = true;
let nativeBtnHandled = false;
let sliderOrientation = "horizontal";
let volumeAlwaysVisible = true;
let seekbarAlwaysVisible = true;
let currentlyPlayingVideo;

function applyVisibility() {
  document.body.classList.toggle("volume-always-visible", volumeAlwaysVisible);
  document.body.classList.toggle("seekbar-always-visible", seekbarAlwaysVisible);
}

// --- Storage ---

let saveDebounceTimer = null;
function saveStates() {
  clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    browser.storage.local.set({
      [STORAGE_KEY]: { volume: videoVolume > 0 ? videoVolume : 0.1 },
    });
  }, 300);
}

// --- Apply helpers ---

function applyToMuteButton(button, muted) {
  button.classList.toggle("muted", muted);
}

function applyToSlider(slider, volume, muted) {
  slider.value = `${(muted ? 0 : volume) * 100}`;
}

function applyStatesToVideo(video) {
  video.volume = videoVolume;
  video.muted = videoMuted;
}

// --- Sync all controls and videos ---
function spreadStates() {
  saveStates();
  for (const container of document.getElementsByClassName("volume-container")) {
    const video = container.parentElement.querySelector('video');
    if (!(video instanceof HTMLVideoElement)) continue;
    applyStatesToVideo(video);
    applyToMuteButton(
      container.querySelector("button.volume-button"),
      videoMuted,
    );
    applyToSlider(
      container.querySelector("input.volume-control"),
      videoVolume,
      videoMuted,
    );
  }
}

// --- Instagram's native mute button ---

function handleDefaultMuteBtn() {
  if (nativeBtnHandled) return;
  // Instagram renders the muted icon when autoplay starts muted
  syncNativeMuteButton()
  const video = [...document.querySelectorAll('video')].filter(v => !v.src || v.src.startsWith('blob'))[0];
  if (video && video.muted != videoMuted) {
    syncNativeMuteButton();
  }
  nativeBtnHandled = true;
}

function syncNativeMuteButton() {
  // Keep our mute state in sync with Instagram's native button
  // select all svgs in case the first one found cannot be clicked (too far away, unrendered)
  const svg = currentlyPlayingVideo.parentElement.querySelector(
    'div[role="group"] div > div[role="button"] > svg, div[role="group"] div.html-div > button > div > svg',
  )
  if (!svg) return;
  const nativeButton = svg.closest('button,[role="button"]');
  if (!nativeButton) return;
  nativeButton.click(); // unmute natively
}

// --- Volume slider ---

function applyVolume(volume) {
  videoVolume = volume;
  if (videoVolume > 0 && videoMuted) {
    videoMuted = false;
    syncNativeMuteButton();
  }
  if (videoVolume == 0 && !videoMuted) {
    videoMuted = true;
    syncNativeMuteButton();
  }
  spreadStates();
}

function toggleMute() {
  videoMuted = !videoMuted;
  syncNativeMuteButton();
  spreadStates();
}

function createVolumeSlider(video) {
  handleDefaultMuteBtn(video);
  applyStatesToVideo(video);

  if (video.dataset.knobAttached) return;
  video.dataset.knobAttached = "true";
  const container = document.createElement("div");
  container.className = "volume-container";

  const STATIC_HTML = `
    <button class="volume-button" aria-label="Toggle mute">
      <svg class="volume-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path class="vi-speaker" d="
          M2.003 11.716C2.04 9.873 2.059 8.952 2.671 8.164
          C2.783 8.02 2.947 7.849 3.084 7.733
          C3.836 7.097 4.83 7.097 6.817 7.097
          C7.527 7.097 7.882 7.097 8.22 7.005
          C8.291 6.985 8.36 6.963 8.429 6.938
          C8.759 6.817 9.056 6.608 9.649 6.192
          L14.138 4.082
          C14.326 4.151 14.508 4.25 14.671 4.372
          C15.519 5.007 15.584 6.487 15.713 9.445
          C15.761 10.541 15.793 11.479 15.793 12
          C15.793 12.522 15.761 13.459 15.713 14.555
          C15.584 17.513 15.519 18.993 14.671 19.628
          C14.508 19.75 14.326 19.849 14.138 19.918
          L9.649 17.808
          C9.056 17.392 8.759 17.183 8.429 17.062
          C8.36 17.037 8.291 17.015 8.22 16.996
          C7.882 16.903 7.527 16.903 6.817 16.903
          C4.83 16.903 3.836 16.903 3.084 16.267
          C2.947 16.151 2.783 15.98 2.671 15.836
          C2.059 15.048 2.04 14.127 2.003 12.285
          C2.001 12.188 2 12.093 2 12
          C2 11.907 2.001 11.812 2.003 11.716Z
        " fill="#fff"/>
        <g class="vi-waves">
          <path opacity="0.5" d="
            M19.489 5.552C19.782 5.292 20.217 5.334 20.461 5.646
            C21.2 6.6 21.639 8.082 21.9 9.85
            C22 10.541 22 11.279 22 12
            C22 12.721 22 13.459 21.9 14.15
            C21.639 15.918 21.2 17.4 20.461 18.354
            C20.217 18.666 19.782 18.708 19.489 18.448
            C19.198 18.19 19.158 17.729 19.398 17.417
            C19.96 16.68 20.337 15.419 20.565 13.795
            C20.655 13.161 20.655 10.839 20.565 10.205
            C20.337 8.581 19.96 7.32 19.398 6.583
            C19.158 6.271 19.198 5.81 19.489 5.552Z
          " fill="#fff"/>
          <path opacity="0.8" d="
            M17.757 8.416C18.09 8.219 18.51 8.347 18.695 8.702
            C19.07 9.415 19.241 10.545 19.241 12
            C19.241 13.455 19.07 14.585 18.695 15.298
            C18.51 15.653 18.09 15.781 17.757 15.585
            C17.427 15.389 17.306 14.947 17.485 14.594
            C17.754 14.065 17.862 13.127 17.862 12
            C17.862 10.873 17.754 9.935 17.485 9.406
            C17.306 9.053 17.427 8.611 17.757 8.416Z
          " fill="#fff"/>
        </g>
        <line class="vi-slash"
          x1="20.5" y1="3.5" x2="3.5" y2="20.5"
          stroke="#fff" stroke-width="1.8" stroke-linecap="round"
        />
      </svg>
    </button>
    <div class="slider-container">
      <input type="range" class="volume-control" min="0" max="100" aria-label="Volume">
    </div>
  `;
  const doc = new DOMParser().parseFromString(STATIC_HTML, "text/html");
  for (const child of doc.body.childNodes) {
    container.appendChild(document.adoptNode(child));
  }
  // Set dynamic attributes via DOM
  const slider = container.querySelector("input.volume-control");
  slider.value = videoMuted ? 0 : videoVolume * 100;
  slider.setAttribute("orient", sliderOrientation);
  container.dataset.orientation = sliderOrientation;
  video.parentElement.prepend(container);

  const button = container.querySelector("button.volume-button");

  applyToMuteButton(button, videoMuted);

  slider.addEventListener("input", (e) => {
    e.stopPropagation();
    applyVolume(slider.value / 100);
  });

  // Prevent Instagram from swallowing click/keyboard events on the slider
  slider.addEventListener("click", (e) => e.stopPropagation());

  button.addEventListener("click", (e) => {
    e.stopPropagation();
    toggleMute()
  });

}

// --- Seek bar ---

function createSeekBar(video) {
  if (video.dataset.seekbarAttached) return;
  video.dataset.seekbarAttached = "true";

  const seekbarContainer = document.createElement("div");
  seekbarContainer.className = "seekbar-container";

  const seekbar = document.createElement("input");
  seekbar.type = "range";
  seekbar.className = "seekbar";
  seekbar.min = "0";
  seekbar.max = "100";
  seekbar.value = "0";
  seekbar.setAttribute("aria-label", "Seek");

  seekbarContainer.append(seekbar);

  video.parentElement.append(seekbarContainer);

  let isSeeking = false;

  seekbar.addEventListener("mousedown", () => {
    isSeeking = true;
  });
  seekbar.addEventListener("touchstart", () => {
    isSeeking = true;
  });

  seekbar.addEventListener("input", (e) => {
    e.stopPropagation();
    if (!isFinite(video.duration)) return;
    video.currentTime = video.duration * (seekbar.value / 100);
  });

  seekbar.addEventListener("mouseup", () => {
    isSeeking = false;
  });
  seekbar.addEventListener("touchend", () => {
    isSeeking = false;
  });

  // Prevent Instagram from swallowing events
  seekbar.addEventListener("click", (e) => e.stopPropagation());

  video.addEventListener("timeupdate", () => {
    // Don't jump the thumb while the user is actively dragging
    if (isSeeking || !isFinite(video.duration)) return;
    seekbar.value = `${(video.currentTime / video.duration) * 100}`;
  });

  video.addEventListener("play", (_) => {
    seekbarContainer.dataset.showPaused = "false"
    setCurrentlyPlayingVideo(video)
  })

  video.addEventListener("pause", (_) => {
    seekbarContainer.dataset.showPaused = "true"
  })

  video.addEventListener('ended', () => {
    if (!autoScroll || document.fullscreenElement) return;
    if (!window.location.href.includes('reels')) return;
    try {
      const nextReelBtn = document.querySelectorAll('div[role="toolbar"] div[role="button"]')[1]
      nextReelBtn?.click()
    } catch { }
  })

  const videoHandler = video.parentElement.querySelector('[role="presentation"')

  videoHandler.addEventListener('dblclick', (e) => {
    toggleFullscreen(video);
  })
}

function setCurrentlyPlayingVideo(video) {
  currentlyPlayingVideo = video;
  video.focus()
}

// --- Auto Scroll ---

function attachAutoScrollBtn() {
  let targets = [...document.querySelectorAll('img[aria-hidden="true"]')]
  if (targets.length == 0 && window.location.href.includes('reels')) {
    //videos replace images
    targets = [...document.querySelectorAll('video')].filter(v => v.src.startsWith('https'))
  }
  const containers = targets.map(img => img.parentElement.parentElement.nextElementSibling);
  containers.forEach(container => {
    if (container.dataset.autoScrollBtnAttached) return;
    const toggle = document.createElement('button');
    toggle.className = "reelsleek-autoscroll"
    toggle.setAttribute('aria-pressed', String(autoScroll));
    toggle.ariaLabel = "Toggle autoscroll"
    toggle.title = "Toggle autoscroll"

    toggle.innerHTML = `
    <svg width="64px" height="64px" viewBox="0 0 16.00 16.00" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="currentColor" stroke-width="0.00016"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill="currentColor" fill-rule="evenodd" d="M8,12 C9.10457,12 10,12.8954 10,14 C10,15.1046 9.10457,16 8,16 C6.89543,16 6,15.1046 6,14 C6,12.8954 6.89543,12 8,12 Z M8,-3.10862447e-14 C8.55229,-3.10862447e-14 9,0.447715 9,1 L9,6.58579 L10.2929,5.2929 C10.6834,4.90237 11.3166,4.90237 11.7071,5.2929 C12.0976,5.68342 12.0976,6.31658 11.7071,6.70711 L8,10.4142 L4.29289,6.70711 C3.90237,6.31658 3.90237,5.68342 4.29289,5.2929 C4.68342,4.90237 5.31658,4.90237 5.70711,5.2929 L7,6.58579 L7,1 C7,0.447715 7.44772,-3.10862447e-14 8,-3.10862447e-14 Z"></path> </g></svg>
    `
    toggle.onclick = (e => {
      e.stopPropagation();
      autoScroll = !autoScroll;
      document.querySelectorAll('.reelsleek-autoscroll').forEach(b => {
        b.setAttribute('aria-pressed', String(autoScroll));
      });
      browser.storage.local.set({ [AUTOSCROLL_ENABLED_KEY]: autoScroll });
    })
    const children = [...container.children];
    const target = children[children.length - 2];
    container.insertBefore(toggle, target);
    container.dataset.autoScrollBtnAttached = "true";
  })
}

// --- Full Screen ---

function toggleFullscreen(video) {
  if (!document.fullscreenElement) {
    video.parentElement.parentElement.requestFullscreen().catch(err => {
      console.error(`Error attempting to enable fullscreen: ${err.message}`);
    });
    // video.controls = false; // Keep it clean
  } else {
    document.exitFullscreen();
  }
}

function createFullscreenButton(video) {
  if (video.dataset.fullscreenAttached) return;
  video.dataset.fullscreenAttached = "true";
  const container = document.createElement("div");
  container.className = "fullscreen-container";

  const STATIC_HTML = `
    <button class="fullscreen-button" aria-label="Toggle fullscreen" title="Toggle fullscreen">
      <svg class="reelsleek-expand-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor"><path d="M280-280h120q17 0 28.5 11.5T440-240q0 17-11.5 28.5T400-200H240q-17 0-28.5-11.5T200-240v-160q0-17 11.5-28.5T240-440q17 0 28.5 11.5T280-400v120Zm400-400H560q-17 0-28.5-11.5T520-720q0-17 11.5-28.5T560-760h160q17 0 28.5 11.5T760-720v160q0 17-11.5 28.5T720-520q-17 0-28.5-11.5T680-560v-120Z"/></svg>
      <svg class="reelsleek-collapse-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor"><path d="M360-360H240q-17 0-28.5-11.5T200-400q0-17 11.5-28.5T240-440h160q17 0 28.5 11.5T440-400v160q0 17-11.5 28.5T400-200q-17 0-28.5-11.5T360-240v-120Zm240-240h120q17 0 28.5 11.5T760-560q0 17-11.5 28.5T720-520H560q-17 0-28.5-11.5T520-560v-160q0-17 11.5-28.5T560-760q17 0 28.5 11.5T600-720v120Z"/></svg>
    </button>
  `;
  const doc = new DOMParser().parseFromString(STATIC_HTML, "text/html");
  for (const child of doc.body.childNodes) {
    container.appendChild(document.adoptNode(child));
  }

  video.parentElement.prepend(container);

  const button = container.querySelector("button");
  button.addEventListener("click", (e) => {
    e.stopPropagation();
    toggleFullscreen(video)
  });
}

// --- Popup Communication ---

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "ping") {
    return Promise.resolve({ ok: true, volume: videoVolume, muted: videoMuted });
  }
  if (msg.type === "setOrientation") {
    sliderOrientation = msg.value;
    document.querySelectorAll(".volume-container").forEach((el) => {
      el.dataset.orientation = msg.value;
      el.querySelector("input.volume-control")?.setAttribute("orient", msg.value);
    });
    return Promise.resolve({ ok: true });
  }
  if (msg.type === "setVolumeAlwaysVisible") {
    volumeAlwaysVisible = msg.value;
    applyVisibility();
    return Promise.resolve({ ok: true });
  }
  if (msg.type === "setSeekbarAlwaysVisible") {
    seekbarAlwaysVisible = msg.value;
    applyVisibility();
    return Promise.resolve({ ok: true });
  }
});

// --- Boot ---

function addKeyboardShortcuts() {
  function stopEvent(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    e.preventDefault();
  }

  document.body.addEventListener("keydown", (e) => {
    const tag = document.activeElement?.tagName;
    //to account for the slider input
    if (tag === "INPUT" && document.activeElement?.type == "text") return;
    if (tag === "TEXTAREA" || document.activeElement?.isContentEditable) return;
    switch (e.code) {
      case "ArrowRight": {
        currentlyPlayingVideo.currentTime += SKIP_SECONDS;
        stopEvent(e)
        break;
      };
      case "ArrowLeft": {
        currentlyPlayingVideo.currentTime -= SKIP_SECONDS;
        stopEvent(e)
        break;
      };
      case "Space": {
        try {
          currentlyPlayingVideo?.parentElement.querySelector('[role="button"][aria-disabled="false"]').click()
        } catch (e) {
          currentlyPlayingVideo.paused ? currentlyPlayingVideo.play() : currentlyPlayingVideo.pause()
        }
        stopEvent(e)
        break;
      };
      case "KeyP": {
        try {
          currentlyPlayingVideo?.parentElement.querySelector('[role="button"][aria-disabled="false"]').click()
        } catch (e) {
          currentlyPlayingVideo.paused ? currentlyPlayingVideo.play() : currentlyPlayingVideo.pause()
        }
        stopEvent(e)
        break;
      };
      case "KeyM": {
        toggleMute();
        break;
      }
      case "Minus": {
        applyVolume(Math.max(videoVolume - VOLUME_STEP, 0));
        break;
      }
      case "Equal": {
        applyVolume(Math.min(videoVolume + VOLUME_STEP, 1));
        break;
      }
      case "KeyF": {
        toggleFullscreen(currentlyPlayingVideo);
        break;
      }
      default: { }
    }
  })
}

async function setup() {
  const result = await browser.storage.local.get([
    STORAGE_KEY,
    ORIENTATION_KEY,
    VOLUME_ALWAYS_VISIBLE_KEY,
    SEEKBAR_ALWAYS_VISIBLE_KEY,
    AUTOSCROLL_ENABLED_KEY
  ]);
  if (result[STORAGE_KEY]) {
    videoVolume = result[STORAGE_KEY].volume ?? 0.1;
  }
  sliderOrientation = result[ORIENTATION_KEY] ?? "horizontal";
  volumeAlwaysVisible = result[VOLUME_ALWAYS_VISIBLE_KEY] ?? volumeAlwaysVisible;
  seekbarAlwaysVisible = result[SEEKBAR_ALWAYS_VISIBLE_KEY] ?? seekbarAlwaysVisible;
  autoScroll = result[AUTOSCROLL_ENABLED_KEY] ?? autoScroll;
  applyVisibility();
  addKeyboardShortcuts();
}

function attachToVideo(video) {
  const src = video.src
  if (src && !src.startsWith('blob')) return;
  if (!currentlyPlayingVideo) setCurrentlyPlayingVideo(video);
  createFullscreenButton(video);
  createVolumeSlider(video);
  createSeekBar(video);
}

(async () => {
  await setup();

  // Attach to any videos already in the DOM
  document.querySelectorAll("video").forEach(attachToVideo);
  attachAutoScrollBtn();
  // Watch for videos added dynamically (Instagram is a SPA)
  const observer = new MutationObserver(() => {
    document.querySelectorAll("video").forEach(attachToVideo);
    attachAutoScrollBtn();
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();