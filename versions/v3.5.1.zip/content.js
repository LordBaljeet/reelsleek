// ============================================================
// Constants
// ============================================================

const STORAGE_KEY = "ig_volume_knob";
const ORIENTATION_KEY = "ig_volume_orientation";
const VOLUME_ALWAYS_VISIBLE_KEY = "ig_volume_always_visible";
const SEEKBAR_ALWAYS_VISIBLE_KEY = "ig_seekbar_always_visible";
const AUTOSCROLL_ENABLED_KEY = "ig_autoscroll";

const SKIP_SECONDS = 5;
const VOLUME_STEP = 0.1;

const VOLUME_BUTTON_HTML = `
  <button class="volume-button" aria-label="Toggle mute">
    <svg class="volume-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path class="vi-speaker" d="
        M2.003 11.716C2.04 9.873 2.059 8.952 2.671 8.164
        C2.783 8.02 2.947 7.849 3.084 7.733
        C3.836 7.097 4.83 7.097 6.817 7.097
        C7.527 7.097 7.882 7.097 8.22 7.005
        C8.291 6.985 8.36 6.963 8.429 6.938
        C8.759 6.817 9.056 6.608 9.649 6.192
        L14.138 4.082
        C14.326 4.151 14.508 4.25 14.671 4.372
        C15.519 5.007 15.584 6.487 15.713 9.445
        C15.761 10.541 15.793 11.479 15.793 12
        C15.793 12.522 15.761 13.459 15.713 14.555
        C15.584 17.513 15.519 18.993 14.671 19.628
        C14.508 19.75 14.326 19.849 14.138 19.918
        L9.649 17.808
        C9.056 17.392 8.759 17.183 8.429 17.062
        C8.36 17.037 8.291 17.015 8.22 16.996
        C7.882 16.903 7.527 16.903 6.817 16.903
        C4.83 16.903 3.836 16.903 3.084 16.267
        C2.947 16.151 2.783 15.98 2.671 15.836
        C2.059 15.048 2.04 14.127 2.003 12.285
        C2.001 12.188 2 12.093 2 12
        C2 11.907 2.001 11.812 2.003 11.716Z
      " fill="#fff"/>
      <g class="vi-waves">
        <path opacity="0.5" d="
          M19.489 5.552C19.782 5.292 20.217 5.334 20.461 5.646
          C21.2 6.6 21.639 8.082 21.9 9.85
          C22 10.541 22 11.279 22 12
          C22 12.721 22 13.459 21.9 14.15
          C21.639 15.918 21.2 17.4 20.461 18.354
          C20.217 18.666 19.782 18.708 19.489 18.448
          C19.198 18.19 19.158 17.729 19.398 17.417
          C19.96 16.68 20.337 15.419 20.565 13.795
          C20.655 13.161 20.655 10.839 20.565 10.205
          C20.337 8.581 19.96 7.32 19.398 6.583
          C19.158 6.271 19.198 5.81 19.489 5.552Z
        " fill="#fff"/>
        <path opacity="0.8" d="
          M17.757 8.416C18.09 8.219 18.51 8.347 18.695 8.702
          C19.07 9.415 19.241 10.545 19.241 12
          C19.241 13.455 19.07 14.585 18.695 15.298
          C18.51 15.653 18.09 15.781 17.757 15.585
          C17.427 15.389 17.306 14.947 17.485 14.594
          C17.754 14.065 17.862 13.127 17.862 12
          C17.862 10.873 17.754 9.935 17.485 9.406
          C17.306 9.053 17.427 8.611 17.757 8.416Z
        " fill="#fff"/>
      </g>
      <line class="vi-slash"
        x1="20.5" y1="3.5" x2="3.5" y2="20.5"
        stroke="#fff" stroke-width="1.8" stroke-linecap="round"
      />
    </svg>
  </button>
  <div class="slider-container">
    <input type="range" class="volume-control" min="0" max="100" aria-label="Volume">
  </div>
`;

const FULLSCREEN_BUTTON_HTML = `
  <button class="fullscreen-button" aria-label="Toggle fullscreen" title="Toggle fullscreen">
    <svg class="reelsleek-expand-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor">
      <path d="M280-280h120q17 0 28.5 11.5T440-240q0 17-11.5 28.5T400-200H240q-17 0-28.5-11.5T200-240v-160q0-17 11.5-28.5T240-440q17 0 28.5 11.5T280-400v120Zm400-400H560q-17 0-28.5-11.5T520-720q0-17 11.5-28.5T560-760h160q17 0 28.5 11.5T760-720v160q0 17-11.5 28.5T720-520q-17 0-28.5-11.5T680-560v-120Z"/>
    </svg>
    <svg class="reelsleek-collapse-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor">
      <path d="M360-360H240q-17 0-28.5-11.5T200-400q0-17 11.5-28.5T240-440h160q17 0 28.5 11.5T440-400v160q0 17-11.5 28.5T400-200q-17 0-28.5-11.5T360-240v-120Zm240-240h120q17 0 28.5 11.5T760-560q0 17-11.5 28.5T720-520H560q-17 0-28.5-11.5T520-560v-160q0-17 11.5-28.5T560-760q17 0 28.5 11.5T600-720v120Z"/>
    </svg>
  </button>
`;

const SVG_NS = "http://www.w3.org/2000/svg";

/** Build the autoscroll button icon using DOM APIs (avoids innerHTML / AMO linter warnings). */
function createAutoscrollIcon() {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("width", "64px");
  svg.setAttribute("height", "64px");
  svg.setAttribute("viewBox", "0 0 16 16");
  svg.setAttribute("fill", "currentColor");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "0.00016");

  const g = document.createElementNS(SVG_NS, "g");
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("fill", "currentColor");
  path.setAttribute("fill-rule", "evenodd");
  path.setAttribute("d", [
    "M8,12 C9.10457,12 10,12.8954 10,14 C10,15.1046 9.10457,16 8,16",
    "C6.89543,16 6,15.1046 6,14 C6,12.8954 6.89543,12 8,12 Z",
    "M8,0 C8.55229,0 9,0.447715 9,1 L9,6.58579 L10.2929,5.2929",
    "C10.6834,4.90237 11.3166,4.90237 11.7071,5.2929",
    "C12.0976,5.68342 12.0976,6.31658 11.7071,6.70711 L8,10.4142",
    "L4.29289,6.70711 C3.90237,6.31658 3.90237,5.68342 4.29289,5.2929",
    "C4.68342,4.90237 5.31658,4.90237 5.70711,5.2929 L7,6.58579 L7,1",
    "C7,0.447715 7.44772,0 8,0 Z",
  ].join(" "));

  g.appendChild(path);
  svg.appendChild(g);
  return svg;
}

// ============================================================
// State
// ============================================================

const state = {
  videoVolume: 0.1,
  videoMuted: false,
  autoScroll: true,
  sliderOrientation: "horizontal",
  volumeAlwaysVisible: true,
  seekbarAlwaysVisible: true,
  currentlyPlayingVideo: null,
  nativeBtnHandled: false,
};

// ============================================================
// Storage
// ============================================================

let saveDebounceTimer = null;

function saveVolume() {
  clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    browser.storage.local.set({
      [STORAGE_KEY]: { volume: state.videoVolume > 0 ? state.videoVolume : 0.1 },
    });
  }, 300);
}

async function loadSettings() {
  const result = await browser.storage.local.get([
    STORAGE_KEY,
    ORIENTATION_KEY,
    VOLUME_ALWAYS_VISIBLE_KEY,
    SEEKBAR_ALWAYS_VISIBLE_KEY,
    AUTOSCROLL_ENABLED_KEY,
  ]);

  if (result[STORAGE_KEY]) {
    state.videoVolume = result[STORAGE_KEY].volume ?? 0.1;
  }

  state.sliderOrientation = result[ORIENTATION_KEY] ?? state.sliderOrientation;
  state.volumeAlwaysVisible = result[VOLUME_ALWAYS_VISIBLE_KEY] ?? state.volumeAlwaysVisible;
  state.seekbarAlwaysVisible = result[SEEKBAR_ALWAYS_VISIBLE_KEY] ?? state.seekbarAlwaysVisible;
  state.autoScroll = result[AUTOSCROLL_ENABLED_KEY] ?? state.autoScroll;
}

// ============================================================
// DOM Helpers
// ============================================================

function parseHTML(html) {
  return new DOMParser().parseFromString(html, "text/html").body.childNodes;
}

function appendParsedHTML(container, html) {
  for (const child of parseHTML(html)) {
    container.appendChild(document.adoptNode(child));
  }
}

function applyVisibilityClasses() {
  document.body.classList.toggle("volume-always-visible", state.volumeAlwaysVisible);
  document.body.classList.toggle("seekbar-always-visible", state.seekbarAlwaysVisible);
}

// ============================================================
// Volume & Mute
// ============================================================

/**
 * Click Instagram's native mute button to keep our state in sync with theirs.
 * Selects from multiple possible DOM structures Instagram may render.
 */
function clickNativeMuteButton() {
  const svg = state.currentlyPlayingVideo?.parentElement?.querySelector(
    'div[role="group"] div > div[role="button"] > svg, div[role="group"] div.html-div > button > div > svg',
  );
  if (!svg) return;

  const nativeButton = svg.closest('button, [role="button"]');
  nativeButton?.click();
}

function syncNativeMuteOnFirstLoad() {
  if (state.nativeBtnHandled) return;
  clickNativeMuteButton();

  const video = [...document.querySelectorAll("video")].find(
    (v) => !v.src || v.src.startsWith("blob"),
  );
  if (video && video.muted !== state.videoMuted) {
    clickNativeMuteButton();
  }

  state.nativeBtnHandled = true;
}

function applyVolumeToVideo(video) {
  video.volume = state.videoVolume;
  video.muted = state.videoMuted;
}

function updateMuteButton(button) {
  button.classList.toggle("muted", state.videoMuted);
}

function updateSlider(slider) {
  slider.value = `${(state.videoMuted ? 0 : state.videoVolume) * 100}`;
}

/** Push current volume/mute state to all active video containers. */
function broadcastState() {
  saveVolume();

  for (const container of document.getElementsByClassName("volume-container")) {
    const video = container.parentElement.querySelector("video");
    if (!(video instanceof HTMLVideoElement)) continue;

    applyVolumeToVideo(video);
    updateMuteButton(container.querySelector("button.volume-button"));
    updateSlider(container.querySelector("input.volume-control"));
  }
}

function setVolume(volume) {
  state.videoVolume = volume;

  if (state.videoVolume > 0 && state.videoMuted) {
    state.videoMuted = false;
    clickNativeMuteButton();
  } else if (state.videoVolume === 0 && !state.videoMuted) {
    state.videoMuted = true;
    clickNativeMuteButton();
  }

  broadcastState();
}

function toggleMute() {
  state.videoMuted = !state.videoMuted;
  clickNativeMuteButton();
  broadcastState();
}

// ============================================================
// Volume Control UI
// ============================================================

function createVolumeControl(video) {
  syncNativeMuteOnFirstLoad();
  applyVolumeToVideo(video);

  if (video.dataset.knobAttached) return;
  video.dataset.knobAttached = "true";

  const container = document.createElement("div");
  container.className = "volume-container";
  container.dataset.orientation = state.sliderOrientation;
  appendParsedHTML(container, VOLUME_BUTTON_HTML);

  const slider = container.querySelector("input.volume-control");
  slider.value = state.videoMuted ? 0 : state.videoVolume * 100;
  slider.setAttribute("orient", state.sliderOrientation);

  const button = container.querySelector("button.volume-button");
  updateMuteButton(button);

  slider.addEventListener("input", (e) => {
    e.stopPropagation();
    setVolume(slider.value / 100);
  });
  slider.addEventListener("click", (e) => e.stopPropagation());

  button.addEventListener("click", (e) => {
    e.stopPropagation();
    toggleMute();
  });

  video.parentElement.prepend(container);
}

// ============================================================
// Seek Bar UI
// ============================================================

function createSeekBar(video) {
  if (video.dataset.seekbarAttached) return;
  video.dataset.seekbarAttached = "true";

  const container = document.createElement("div");
  container.className = "seekbar-container";

  const seekbar = document.createElement("input");
  seekbar.type = "range";
  seekbar.className = "seekbar";
  seekbar.min = "0";
  seekbar.max = "100";
  seekbar.value = "0";
  seekbar.setAttribute("aria-label", "Seek");

  container.append(seekbar);
  video.parentElement.append(container);

  let isSeeking = false;

  seekbar.addEventListener("mousedown", () => { isSeeking = true; });
  seekbar.addEventListener("touchstart", () => { isSeeking = true; });
  seekbar.addEventListener("mouseup", () => { isSeeking = false; });
  seekbar.addEventListener("touchend", () => { isSeeking = false; });

  seekbar.addEventListener("input", (e) => {
    e.stopPropagation();
    if (!isFinite(video.duration)) return;
    video.currentTime = video.duration * (seekbar.value / 100);
  });

  seekbar.addEventListener("click", (e) => e.stopPropagation());

  video.addEventListener("timeupdate", () => {
    if (isSeeking || !isFinite(video.duration)) return;
    seekbar.value = `${(video.currentTime / video.duration) * 100}`;
  });

  video.addEventListener("play", () => {
    container.dataset.showPaused = "false";
    setCurrentlyPlaying(video);
  });

  video.addEventListener("pause", () => {
    container.dataset.showPaused = "true";
  });

  video.addEventListener("ended", onVideoEnded);

  const presentationEl = video.parentElement.querySelector('[role="presentation"]');
  presentationEl?.addEventListener("dblclick", () => toggleFullscreen(video));
}

function onVideoEnded() {
  if (!state.autoScroll) return;
  if (document.fullscreenElement) return;
  if (!window.location.href.includes("reels")) return;
  if (document.querySelector('[role="dialog"]')) return;

  try {
    const nextButton = document.querySelectorAll('div[role="toolbar"] div[role="button"]')[1];
    nextButton?.click();
  } catch { /* no-op */ }
}

// ============================================================
// Fullscreen
// ============================================================

function toggleFullscreen(video) {
  if (!document.fullscreenElement) {
    video.parentElement.parentElement.requestFullscreen().catch((err) => {
      console.error(`Fullscreen error: ${err.message}`);
    });
  } else {
    document.exitFullscreen();
  }
}

function createFullscreenButton(video) {
  if (video.dataset.fullscreenAttached) return;
  video.dataset.fullscreenAttached = "true";

  const container = document.createElement("div");
  container.className = "fullscreen-container";
  appendParsedHTML(container, FULLSCREEN_BUTTON_HTML);

  container.querySelector("button").addEventListener("click", (e) => {
    e.stopPropagation();
    toggleFullscreen(video);
  });

  video.parentElement.prepend(container);
}

// ============================================================
// Auto-Scroll Button
// ============================================================

function attachAutoScrollButtons() {
  let targets = [...document.querySelectorAll('img[aria-hidden="true"]')];

  // On reels pages, videos replace the images
  if (targets.length === 0 && window.location.href.includes("reels")) {
    targets = [...document.querySelectorAll("video")].filter((v) =>
      v.src.startsWith("https"),
    );
  }

  for (const target of targets) {
    const container = target.parentElement?.parentElement?.nextElementSibling;
    if (!container || container.dataset.autoScrollBtnAttached) continue;

    const button = document.createElement("button");
    button.className = "reelsleek-autoscroll";
    button.setAttribute("aria-pressed", String(state.autoScroll));
    button.setAttribute("aria-label", "Toggle autoscroll");
    button.title = "Toggle autoscroll";
    button.appendChild(createAutoscrollIcon());

    button.addEventListener("click", (e) => {
      e.stopPropagation();
      state.autoScroll = !state.autoScroll;

      applyAutoscrollToggleState();

      browser.storage.local.set({ [AUTOSCROLL_ENABLED_KEY]: state.autoScroll });
    });

    const children = [...container.children];
    container.insertBefore(button, children[children.length - 2]);
    container.dataset.autoScrollBtnAttached = "true";
  }
}

function applyAutoscrollToggleState() {
  document.querySelectorAll(".reelsleek-autoscroll").forEach((btn) => {
    btn.setAttribute("aria-pressed", String(state.autoScroll));
  });
}

// ============================================================
// Currently Playing Video
// ============================================================

function setCurrentlyPlaying(video) {
  state.currentlyPlayingVideo = video;
  video.focus();
}

// ============================================================
// Keyboard Shortcuts
// ============================================================

function addKeyboardShortcuts() {
  document.body.addEventListener("keydown", (e) => {
    const { tagName, type, isContentEditable } = document.activeElement ?? {};

    // Ignore text input fields
    if (tagName === "INPUT" && type === "text") return;
    if (tagName === "TEXTAREA" || isContentEditable) return;

    const video = state.currentlyPlayingVideo;

    const stop = () => {
      e.stopPropagation();
      e.stopImmediatePropagation();
      e.preventDefault();
    };

    const tryClickPlayButton = () => {
      try {
        video?.parentElement
          ?.querySelector('[role="button"][aria-disabled="false"]')
          ?.click();
      } catch {
        if (video) {
          video.paused ? video.play() : video.pause();
        }
      }
    };

    switch (e.code) {
      case "ArrowRight":
        if (video) video.currentTime += SKIP_SECONDS;
        stop();
        break;

      case "ArrowLeft":
        if (video) video.currentTime -= SKIP_SECONDS;
        stop();
        break;

      case "Space":
      case "KeyP":
        tryClickPlayButton();
        stop();
        break;

      case "KeyM":
        toggleMute();
        break;

      case "Minus":
        setVolume(Math.max(state.videoVolume - VOLUME_STEP, 0));
        break;

      case "Equal":
        setVolume(Math.min(state.videoVolume + VOLUME_STEP, 1));
        break;

      case "KeyF":
        if (video) toggleFullscreen(video);
        break;
    }
  });
}

// ============================================================
// Extension Messaging
// ============================================================

browser.runtime.onMessage.addListener((msg) => {
  switch (msg.type) {
    case "ping":
      return Promise.resolve({
        ok: true,
        volume: state.videoVolume,
        muted: state.videoMuted,
      });

    case "setOrientation":
      state.sliderOrientation = msg.value;
      document.querySelectorAll(".volume-container").forEach((el) => {
        el.dataset.orientation = msg.value;
        el.querySelector("input.volume-control")?.setAttribute("orient", msg.value);
      });
      return Promise.resolve({ ok: true });

    case "setVolumeAlwaysVisible":
      state.volumeAlwaysVisible = msg.value;
      applyVisibilityClasses();
      return Promise.resolve({ ok: true });

    case "setSeekbarAlwaysVisible":
      state.seekbarAlwaysVisible = msg.value;
      applyVisibilityClasses();
      return Promise.resolve({ ok: true });
    
    case "setAutoscroll":
      state.autoScroll = msg.value;
      applyAutoscrollToggleState();
      return Promise.resolve({ ok: true });
  }
});

// ============================================================
// Video Attachment
// ============================================================

/**
 * Attach all controls to a video element.
 * Skips external (non-blob) src videos that Instagram uses for preview thumbnails.
 */
function attachToVideo(video) {
  if (video.src && !video.src.startsWith("blob")) return;
  if (!state.currentlyPlayingVideo) setCurrentlyPlaying(video);

  createFullscreenButton(video);
  createVolumeControl(video);
  createSeekBar(video);
}

// ============================================================
// Initialisation
// ============================================================

(async () => {
  await loadSettings();
  applyVisibilityClasses();
  addKeyboardShortcuts();

  document.querySelectorAll("video").forEach(attachToVideo);
  attachAutoScrollButtons();

  // Watch for dynamically added videos (Instagram is a SPA)
  const observer = new MutationObserver(() => {
    document.querySelectorAll("video").forEach(attachToVideo);
    attachAutoScrollButtons();
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();