const STORAGE_KEY = "ig_volume_knob";
const ORIENTATION_KEY = "ig_volume_orientation";
const VOLUME_ALWAYS_VISIBLE_KEY = "ig_volume_always_visible";
const SEEKBAR_ALWAYS_VISIBLE_KEY = "ig_seekbar_always_visible";

let videoVolume = 0.1;
let videoMuted = false;
let nativeBtnHandled = false;
let sliderOrientation = "horizontal";
let volumeAlwaysVisible = false;
let seekbarAlwaysVisible = false;

function applyVisibility() {
  document.body.classList.toggle("volume-always-visible", volumeAlwaysVisible);
  document.body.classList.toggle("seekbar-always-visible", seekbarAlwaysVisible);
}

// --- Storage ---

let saveDebounceTimer = null;
function saveStates() {
  clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    browser.storage.local.set({
      [STORAGE_KEY]: { volume: videoVolume > 0 ? videoVolume : 0.1 },
    });
  }, 300);
}

// --- Apply helpers ---

function applyToMuteButton(button, muted) {
  button.classList.toggle("muted", muted);
}

function applyToSlider(slider, volume, muted) {
  slider.value = `${(muted ? 0 : volume) * 100}`;
}

function applyStatesToVideo(video) {
  video.volume = videoVolume;
  video.muted = videoMuted;
}

// --- Sync all controls and videos ---

function spreadStates() {
  saveStates();
  for (const container of document.getElementsByClassName("volume-container")) {
    const video = container.nextSibling;
    if (!(video instanceof HTMLVideoElement)) continue;
    applyStatesToVideo(video);
    applyToMuteButton(
      container.querySelector("button.volume-button"),
      videoMuted,
    );
    applyToSlider(
      container.querySelector("input.volume-control"),
      videoVolume,
      videoMuted,
    );
  }
}

// --- Instagram's native mute button ---

function handleDefaultMuteBtn(video) {
  findNativeMuteButton(video.parentElement);
  if (nativeBtnHandled) return;
  syncNativeMuteButton(video.parentElement);
  nativeBtnHandled = true;
}

// Match Instagram's native audio button by fingerprinting the SVG path data.
// Paths are normalised (whitespace stripped) before matching to survive
// Instagram's SVG minifier reformatting arc flags between deploys.
// Two fingerprints cover both icon states (playing + muted).
const IG_AUDIO_PATH_FINGERPRINTS = [
  // Playing — longest common substring across all known "playing" variants
  "m3.73-2.332A1.51.501018.046.598.8238.8230012012.007a8.7988.798001-1.965.4151.51.50002.3261.89411.67211.6720002.635-7.3111.68211.682000-2.635-7.31",
  // Muted — unique to the slashed-speaker icon
  "M1.513.3c-.80-1",
];

function findNativeMuteButton(root = document) {
  let target = null;
  for (const path of root.querySelectorAll("svg path")) {
    const d = (path.getAttribute("d") ?? "").replace(/\s+/g, "");
    if (IG_AUDIO_PATH_FINGERPRINTS.some((fp) => d.includes(fp))) {
      const btn = path.closest('button,[role="button"]');
      if (btn) {
        btn.dataset.reelsleekNativeBtn = "true";
        target =  btn;
      }
    }
  }
  return target;
}

function syncNativeMuteButton(root = document) {
  const nativeButton = findNativeMuteButton(root);
  if (!nativeButton) return;
  nativeButton.click();
}

// --- Volume slider ---

function createVolumeSlider(video) {
  handleDefaultMuteBtn(video);
  applyStatesToVideo(video);

  if (video.dataset.knobAttached) return;
  video.dataset.knobAttached = "true";
  const container = document.createElement("div");
  container.className = "volume-container";

  const STATIC_HTML = `
    <button class="volume-button" aria-label="Toggle mute">
      <svg class="volume-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path class="vi-speaker" d="
          M2.003 11.716C2.04 9.873 2.059 8.952 2.671 8.164
          C2.783 8.02 2.947 7.849 3.084 7.733
          C3.836 7.097 4.83 7.097 6.817 7.097
          C7.527 7.097 7.882 7.097 8.22 7.005
          C8.291 6.985 8.36 6.963 8.429 6.938
          C8.759 6.817 9.056 6.608 9.649 6.192
          L14.138 4.082
          C14.326 4.151 14.508 4.25 14.671 4.372
          C15.519 5.007 15.584 6.487 15.713 9.445
          C15.761 10.541 15.793 11.479 15.793 12
          C15.793 12.522 15.761 13.459 15.713 14.555
          C15.584 17.513 15.519 18.993 14.671 19.628
          C14.508 19.75 14.326 19.849 14.138 19.918
          L9.649 17.808
          C9.056 17.392 8.759 17.183 8.429 17.062
          C8.36 17.037 8.291 17.015 8.22 16.996
          C7.882 16.903 7.527 16.903 6.817 16.903
          C4.83 16.903 3.836 16.903 3.084 16.267
          C2.947 16.151 2.783 15.98 2.671 15.836
          C2.059 15.048 2.04 14.127 2.003 12.285
          C2.001 12.188 2 12.093 2 12
          C2 11.907 2.001 11.812 2.003 11.716Z
        " fill="#fff"/>
        <g class="vi-waves">
          <path opacity="0.5" d="
            M19.489 5.552C19.782 5.292 20.217 5.334 20.461 5.646
            C21.2 6.6 21.639 8.082 21.9 9.85
            C22 10.541 22 11.279 22 12
            C22 12.721 22 13.459 21.9 14.15
            C21.639 15.918 21.2 17.4 20.461 18.354
            C20.217 18.666 19.782 18.708 19.489 18.448
            C19.198 18.19 19.158 17.729 19.398 17.417
            C19.96 16.68 20.337 15.419 20.565 13.795
            C20.655 13.161 20.655 10.839 20.565 10.205
            C20.337 8.581 19.96 7.32 19.398 6.583
            C19.158 6.271 19.198 5.81 19.489 5.552Z
          " fill="#fff"/>
          <path opacity="0.8" d="
            M17.757 8.416C18.09 8.219 18.51 8.347 18.695 8.702
            C19.07 9.415 19.241 10.545 19.241 12
            C19.241 13.455 19.07 14.585 18.695 15.298
            C18.51 15.653 18.09 15.781 17.757 15.585
            C17.427 15.389 17.306 14.947 17.485 14.594
            C17.754 14.065 17.862 13.127 17.862 12
            C17.862 10.873 17.754 9.935 17.485 9.406
            C17.306 9.053 17.427 8.611 17.757 8.416Z
          " fill="#fff"/>
        </g>
        <line class="vi-slash"
          x1="20.5" y1="3.5" x2="3.5" y2="20.5"
          stroke="#fff" stroke-width="1.8" stroke-linecap="round"
        />
      </svg>
    </button>
    <div class="slider-container">
      <input type="range" class="volume-control" min="0" max="100" aria-label="Volume">
    </div>
  `;
  const doc = new DOMParser().parseFromString(STATIC_HTML, "text/html");
  for (const child of doc.body.childNodes) {
    container.appendChild(document.adoptNode(child));
  }
  // Set dynamic attributes via DOM
  const slider = container.querySelector("input.volume-control");
  slider.value = videoMuted ? 0 : videoVolume * 100;
  slider.setAttribute("orient", sliderOrientation);
  container.dataset.orientation = sliderOrientation;
  video.parentElement.prepend(container);

  const button = container.querySelector("button.volume-button");

  applyToMuteButton(button, videoMuted);

  slider.addEventListener("input", (e) => {
    e.stopPropagation();
    videoVolume = slider.value / 100;
    // Unmute automatically when the user drags the slider up from 0
    if (videoVolume > 0 && videoMuted) {
      videoMuted = false;
      syncNativeMuteButton(video.parentElement);
    }
    if (videoVolume == 0 && !videoMuted) {
      videoMuted = true;
      syncNativeMuteButton(video.parentElement);
    }
    spreadStates();
  });

  // Prevent Instagram from swallowing click/keyboard events on the slider
  slider.addEventListener("click", (e) => e.stopPropagation());
  slider.addEventListener("keydown", (e) => e.stopPropagation());

  button.addEventListener("click", (e) => {
    e.stopPropagation();
    videoMuted = !videoMuted;
    syncNativeMuteButton(video.parentElement);
    spreadStates();
  });

}

// --- Seek bar ---

function createSeekBar(video) {
  if (video.dataset.seekbarAttached) return;
  video.dataset.seekbarAttached = "true";

  const seekbar = document.createElement("input");
  seekbar.type = "range";
  seekbar.className = "seekbar";
  seekbar.min = "0";
  seekbar.max = "100";
  seekbar.value = "0";
  seekbar.setAttribute("aria-label", "Seek");

  video.parentElement.append(seekbar);

  let isSeeking = false;

  seekbar.addEventListener("mousedown", () => {
    isSeeking = true;
  });
  seekbar.addEventListener("touchstart", () => {
    isSeeking = true;
  });

  seekbar.addEventListener("input", (e) => {
    e.stopPropagation();
    if (!isFinite(video.duration)) return;
    video.currentTime = video.duration * (seekbar.value / 100);
  });

  seekbar.addEventListener("mouseup", () => {
    isSeeking = false;
  });
  seekbar.addEventListener("touchend", () => {
    isSeeking = false;
  });

  // Prevent Instagram from swallowing events
  seekbar.addEventListener("click", (e) => e.stopPropagation());
  seekbar.addEventListener("keydown", (e) => e.stopPropagation());

  video.addEventListener("timeupdate", () => {
    // Don't jump the thumb while the user is actively dragging
    if (isSeeking || !isFinite(video.duration)) return;
    seekbar.value = `${(video.currentTime / video.duration) * 100}`;
  });
}

// --- Popup Communication ---

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "ping") {
    return Promise.resolve({ ok: true, volume: videoVolume, muted: videoMuted });
  }
  if (msg.type === "setOrientation") {
    sliderOrientation = msg.value;
    document.querySelectorAll(".volume-container").forEach((el) => {
      el.dataset.orientation = msg.value;
      el.querySelector("input.volume-control")?.setAttribute("orient", msg.value);
    });
    return Promise.resolve({ ok: true });
  }
  if (msg.type === "setVolumeAlwaysVisible") {
    volumeAlwaysVisible = msg.value;
    applyVisibility();
    return Promise.resolve({ ok: true });
  }
  if (msg.type === "setSeekbarAlwaysVisible") {
    seekbarAlwaysVisible = msg.value;
    applyVisibility();
    return Promise.resolve({ ok: true });
  }
});

// --- Boot ---

async function setup() {
  const result = await browser.storage.local.get([
    STORAGE_KEY,
    ORIENTATION_KEY,
    VOLUME_ALWAYS_VISIBLE_KEY,
    SEEKBAR_ALWAYS_VISIBLE_KEY,
  ]);
  if (result[STORAGE_KEY]) {
    videoVolume = result[STORAGE_KEY].volume ?? 0.1;
  }
  sliderOrientation = result[ORIENTATION_KEY] ?? "horizontal";
  volumeAlwaysVisible = result[VOLUME_ALWAYS_VISIBLE_KEY] ?? false;
  seekbarAlwaysVisible = result[SEEKBAR_ALWAYS_VISIBLE_KEY] ?? false;
  applyVisibility();
}

function attachToVideo(video) {
  const src = video.src
  if (!src || src.startsWith('blob')) {
    createVolumeSlider(video);
    createSeekBar(video);
  }
}

(async () => {
  await setup();

  // Attach to any videos already in the DOM
  document.querySelectorAll("video").forEach(attachToVideo);
  // Watch for videos added dynamically (Instagram is a SPA)
  const observer = new MutationObserver(() => {
    document.querySelectorAll("video").forEach(attachToVideo);
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();